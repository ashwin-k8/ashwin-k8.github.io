#include <Wire.h>
#include <SPI.h>
#include <LoRa.h>
#include <Adafruit_VL53L0X.h>
#include <Adafruit_SSD1306.h>

// ------------ CONFIG (edit per-board) ------------
#define CAR_ID 2               // unique ID for this OBU (1,2,...)
#define HAS_SENSOR 1           // 1 = this board has VL53L0X, 0 = no sensor
#define TARGET_ID 2            // 0 = use peer discovery; >0 = force send addressed to this ID
#define LORA_FREQ   433E6
#define COLLISION_THRESHOLD 100
#define COLLISION_COOLDOWN_MS 1200
#define STATUS_BROADCAST_INTERVAL_MS 800
#define ALERT_TIMEOUT_MS 5000
#define PEER_EXPIRY_MS 5000
#define MAX_PEERS 8
// -------------------------------------------------

// LoRa SPI pins (ESP32)
#define LORA_SCK 18
#define LORA_MISO 19
#define LORA_MOSI 23
#define LORA_SS 5
#define LORA_RST 14
#define LORA_DIO0 26

// OLED
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// VL53L0X
Adafruit_VL53L0X lox;

// Peer struct
struct PeerInfo {
  int id;
  int lastDist;
  unsigned long lastSeen;
};
PeerInfo peers[MAX_PEERS];

// State
unsigned long lastCollisionSent = 0;
unsigned long lastStatusSent = 0;
bool localCollisionActive = false;
int lastLocalDistance = 0;

bool recvCollisionActive = false;
int recvCollisionFrom = -1;
int recvCollisionDist = 0;
unsigned long recvCollisionTime = 0;

bool sensorAvailable = false; // will be true if VL53 initialized successfully

void setup() {
  Serial.begin(115200);
  delay(100);

  // OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
    while (1) delay(10);
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  // init peer table
  for (int i = 0; i < MAX_PEERS; i++) {
    peers[i].id = -1;
    peers[i].lastDist = 0;
    peers[i].lastSeen = 0;
  }

  // I2C & VL53 - attempt init only if HAS_SENSOR==1
  Wire.begin(); // default SDA=21 SCL=22 on many ESP32s
  sensorAvailable = false;
#if HAS_SENSOR
  if (lox.begin()) {
    sensorAvailable = true;
    Serial.println("VL53L0X initialized");
  } else {
    // If we required a sensor but it failed, we can continue in fallback mode,
    // but report the error. Set sensorAvailable=false so loop uses DIST=0.
    Serial.println("VL53L0X not found - running without sensor");
    sensorAvailable = false;
  }
#else
  Serial.println("Running without VL53 sensor (HAS_SENSOR=0)");
#endif

  // LoRa init
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);
  if (!LoRa.begin(LORA_FREQ)) {
    Serial.println("LoRa init failed");
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0,0);
    display.println("LoRa init failed!");
    display.display();
    while (1) delay(10);
  }
  LoRa.setSyncWord(0xF3);

  Serial.printf("OBU ready - CAR_ID=%d HAS_SENSOR=%d TARGET_ID=%d\n", CAR_ID, HAS_SENSOR, TARGET_ID);
}

// peer helpers
PeerInfo* findPeer(int id) {
  for (int i = 0; i < MAX_PEERS; i++) if (peers[i].id == id) return &peers[i];
  for (int i = 0; i < MAX_PEERS; i++) if (peers[i].id < 0) {
    peers[i].id = id; peers[i].lastDist = 0; peers[i].lastSeen = 0; return &peers[i];
  }
  int oldest = 0;
  for (int i = 1; i < MAX_PEERS; i++) if (peers[i].lastSeen < peers[oldest].lastSeen) oldest = i;
  peers[oldest].id = id; peers[oldest].lastDist = 0; peers[oldest].lastSeen = 0;
  return &peers[oldest];
}

void sendStatusBroadcast(int distance_mm) {
  unsigned long now = millis();
  if (now - lastStatusSent < STATUS_BROADCAST_INTERVAL_MS) return;
  lastStatusSent = now;
  String msg = "OBU:" + String(CAR_ID) + ",DIST:" + String(distance_mm);
  LoRa.beginPacket(); LoRa.print(msg); LoRa.endPacket();
}

int chooseTargetPeer() {
  int targetId = -1; int bestDist = 999999; unsigned long now = millis();
  for (int i = 0; i < MAX_PEERS; i++) {
    if (peers[i].id > 0 && peers[i].id != CAR_ID && (now - peers[i].lastSeen) <= PEER_EXPIRY_MS) {
      if (peers[i].lastDist > 0 && peers[i].lastDist < bestDist) {
        bestDist = peers[i].lastDist; targetId = peers[i].id;
      }
    }
  }
  return targetId;
}

void sendCollisionAlertTo(int targetID, int distance_mm) {
  unsigned long now = millis();
  if (now - lastCollisionSent < COLLISION_COOLDOWN_MS) return;
  lastCollisionSent = now;
  String msg = "COLLISION,FROM:" + String(CAR_ID) + ",TO:" + String(targetID) + ",DIST:" + String(distance_mm);
  LoRa.beginPacket(); LoRa.print(msg); LoRa.endPacket();
  Serial.println("Sent addressed: " + msg);
  localCollisionActive = true;
}

void handleLoRaMessage(String s) {
  s.trim();
  Serial.println("RX: " + s);
  int idxTO = s.indexOf("TO:");
  int toId = -1;
  if (idxTO >= 0) {
    int endIdx = s.indexOf(',', idxTO);
    if (endIdx < 0) endIdx = s.length();
    String toStr = s.substring(idxTO + 3, endIdx);
    toStr.trim();
    toId = toStr.toInt();
  }
  if (idxTO >= 0 && toId != 0 && toId != CAR_ID) {
    Serial.println("Not for me (TO:" + String(toId) + ")");
    return;
  }

  if (s.startsWith("OBU:")) {
    int idxDist = s.indexOf(",DIST:");
    if (idxDist > 0) {
      String idStr = s.substring(4, idxDist);
      int id = idStr.toInt();
      String distStr = s.substring(idxDist + 6);
      int dist = distStr.toInt();
      if (id > 0 && id != CAR_ID) {
        PeerInfo* p = findPeer(id);
        p->lastDist = dist; p->lastSeen = millis();
        Serial.printf("Updated peer %d dist=%d\n", id, dist);
      }
    }
    return;
  }

  if (s.startsWith("COLLISION")) {
    int idxFrom = s.indexOf("FROM:");
    int idxDist = s.indexOf(",DIST:");
    if (idxFrom >= 0 && idxDist >= 0) {
      String fromStr = s.substring(idxFrom + 5, idxDist);
      int fromId = fromStr.toInt();
      String distStr = s.substring(idxDist + 6);
      int dist = distStr.toInt();
      recvCollisionActive = true; recvCollisionFrom = fromId; recvCollisionDist = dist; recvCollisionTime = millis();
      Serial.printf("Collision alert for me from %d dist %d\n", fromId, dist);
    } else {
      recvCollisionActive = true; recvCollisionFrom = -1; recvCollisionDist = 0; recvCollisionTime = millis();
    }
    return;
  }
}

void checkLoRaReceive() {
  int packetSize = LoRa.parsePacket();
  if (packetSize) {
    String r = "";
    while (LoRa.available()) r += (char)LoRa.read();
    handleLoRaMessage(r);
  }
}

void updateAlertTimeouts() {
  unsigned long now = millis();
  if (localCollisionActive && (now - lastCollisionSent > ALERT_TIMEOUT_MS)) localCollisionActive = false;
  if (recvCollisionActive && (now - recvCollisionTime > ALERT_TIMEOUT_MS)) {
    recvCollisionActive = false; recvCollisionFrom = -1; recvCollisionDist = 0;
  }
  for (int i = 0; i < MAX_PEERS; i++) {
    if (peers[i].id > 0 && (millis() - peers[i].lastSeen) > PEER_EXPIRY_MS) {
      peers[i].id = -1; peers[i].lastDist = 0; peers[i].lastSeen = 0;
    }
  }
}

void drawDisplay(int distance_mm) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.printf("CarID:%d\n", CAR_ID);
  display.print("Front: ");
  if (distance_mm == 0 || distance_mm > 5000) display.println("Out of range");
  else { display.print(distance_mm); display.println(" mm"); }
  if (localCollisionActive) {
    display.setTextSize(2); display.setCursor(0, 24); display.println("LOCAL COLLISION"); display.setTextSize(1);
  }
  if (recvCollisionActive) {
    display.setCursor(0, 40);
    if (recvCollisionFrom >= 0) display.printf("ALERT from %d: %d mm\n", recvCollisionFrom, recvCollisionDist);
    else display.println("ALERT: collision");
  } else {
    int y = 32; display.setCursor(0, y); display.println("Peers:"); int row = 0;
    for (int i = 0; i < MAX_PEERS; i++) {
      if (peers[i].id > 0) {
        int py = y + 8 + (row * 8); display.setCursor(0, py);
        display.printf("%d:%dmm ", peers[i].id, peers[i].lastDist); row++;
        if (row >= 3) break;
      }
    }
  }
  display.display();
}

void loop() {
  // read distance: if we have a sensor and it's available, read it; else distance=0
  int distance = 0;
  if (HAS_SENSOR && sensorAvailable) {
    VL53L0X_RangingMeasurementData_t measure;
    lox.rangingTest(&measure, false);
    distance = (measure.RangeStatus != 4) ? measure.RangeMilliMeter : 0;
  } else {
    distance = 0; // indicate no local measurement
  }
  lastLocalDistance = distance;

  // broadcast status (even if distance==0) so other nodes discover us
  sendStatusBroadcast(distance);

  // receive incoming messages
  checkLoRaReceive();

  // collision detection: only meaningful if this board has a sensor and measured a distance
  if (HAS_SENSOR && sensorAvailable && distance > 0 && distance < COLLISION_THRESHOLD) {
    int target = TARGET_ID > 0 ? TARGET_ID : chooseTargetPeer();
    if (target > 0) {
      sendCollisionAlertTo(target, distance);
    } else {
      Serial.println("Collision but no target known; not sending addressed alert");
    }
  }

  updateAlertTimeouts();
  drawDisplay(distance);

  delay(80);
}

